

print(__name__)

