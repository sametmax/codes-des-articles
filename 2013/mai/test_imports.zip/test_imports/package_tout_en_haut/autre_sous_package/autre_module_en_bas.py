


print(__name__)
