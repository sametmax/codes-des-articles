

print(__name__)


